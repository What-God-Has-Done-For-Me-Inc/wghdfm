class APIPref {
  static const String success = "Success";
  static const String error = "Error";
  static const String warning = "Warning";
}
