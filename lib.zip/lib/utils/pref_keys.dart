class PrefKeys {
  static const String IS_LOGIN = "IsLoggedIn";
}
