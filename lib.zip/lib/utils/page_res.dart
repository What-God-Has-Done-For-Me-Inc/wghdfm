class PageRes {
  static const String loginScreen = "/loginScreen";
  static const String signUpScreen = "/signUpScreen";
  static const String dashBoardScreen = "/DashBoardScreen";
  static const String postDetailScreen = "/postDetailScreen";
  static const String profileScreen = "/profileScreen";
  static const String captureImgVidScreen = "/captureImgVidScreen";
  static const String recoverPassword = "/recoverPassword";
  static const String favouriteScreen = "/favouriteScreen";
  static const String friendScreen = "/friendScreen";
  static const String commentScreen = "/CommentScreen";
}
