const String bibleUrl = "https://whatgodhasdoneforme.com/bible/audio.php";
String chatUrl = "https://whatgodhasdoneforme.com/im-messenger/userview";
String christianNewsUrl = "https://christiannews.net/";
String ourDailyBreadUrl = "https://odb.org/";
String christianBooks = "https://www.christianbook.com/Christian/Books/home?event=AFF&p=1181428";
