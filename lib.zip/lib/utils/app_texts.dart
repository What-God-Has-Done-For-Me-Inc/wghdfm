class AppTexts {
  static const String login = "login";
  static const String dashBoard = "Dashboard";
  static const String profile = "Profile";
  static const String someoneProfile = "SomeoneProfile";
  static const String favorite = "Favorite";
  static const String group = "Group";
  static const String friends = "Friends";
  static const String donate = "Donate";
  static const String notification = "Notification";

  static const String eulaLink = "https://drive.google.com/file/d/1Qok5J-gJF9ESXCXhlHnZYP009wNP4S6x/view?usp=sharing";
}
