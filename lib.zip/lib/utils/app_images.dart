class AppImages {
  static String loadingJson = "assets/json/loading.json";
  static String noInternetJson = "assets/json/no_internet.json";
  static String logoImage = "assets/logo.png";
  static String searchJson = "assets/json/search_lottie.json";
}
