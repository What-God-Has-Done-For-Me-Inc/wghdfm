import 'package:get/get.dart';
import 'package:wghdfm_java/model/my_profilr_details_model.dart';

// MyProfile? detail;
RxList<MyProfile>? detail = <MyProfile>[].obs;

class ProfileApi {}
