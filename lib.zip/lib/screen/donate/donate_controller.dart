import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class DonateController extends GetxController {
  String whyNWhat = "Why we do what we do";
  String ourMission =
      "This is a social network site where people can be like minded in glorifying the Lord.\n\nWhatGodhasDoneForMe.com is a place where we can encourage each other and celebrate with one another the awesome presence of the Lord in our lives.\n\nThis site transcends race, denomination, age and gender. It is a place where people all over the world can glorify the Lord for what he has done in their lives, a place where we are able to harvest the testimonies of others and share within our social groups and deliver directly to the heart of someone in need, is Our Mission";

  String ourObjective =
      "To have a fully functional social network that is solvent, sustainable and profitable, which is also an effective tool for sharing the things of God, and a resource for charitable giving.\n\nIt is only with the help and contributions of our partners (like you) that we'll be able to achieve the momentum it take's to change the world.";

  TextEditingController donationAmtTEC = TextEditingController();
}
